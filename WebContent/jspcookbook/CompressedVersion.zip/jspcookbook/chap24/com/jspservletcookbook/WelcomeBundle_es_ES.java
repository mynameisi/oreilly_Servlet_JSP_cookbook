package com.jspservletcookbook;           

import java.util.ListResourceBundle;
 
public class WelcomeBundle_es_ES extends ListResourceBundle {
     
	 static final Object[][] contents = {
  
         {"Welcome", "Hola y recepci�n"}
     };
	 
	 public Object[][] getContents() {
         return contents;
     }
     
 }
